#!/usr/bin/env bash
export DOORSTOP_ENABLED=1
