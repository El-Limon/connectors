#!/usr/bin/env bash
# fixture
